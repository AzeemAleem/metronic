module.exports = require('./configureStore.dev');
