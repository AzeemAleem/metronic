export const roles = {
    user: "user",
    driver: 'driver'
}